
public class HumanTest {

	public static void main(String[] args) {
		Human lana = new Human();
		Human omar = new Human();
		System.out.println(lana.attack(omar));
	}

}
