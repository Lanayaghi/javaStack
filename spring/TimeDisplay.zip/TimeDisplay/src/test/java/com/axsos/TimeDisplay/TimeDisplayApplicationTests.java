package com.axsos.TimeDisplay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeDisplayApplicationTests {

	@Test
	void contextLoads() {
	}

}
