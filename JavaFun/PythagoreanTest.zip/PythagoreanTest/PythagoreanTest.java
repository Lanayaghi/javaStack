public class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean iD = new Pythagorean() ;
        double result = iD.calculateHypotenuse(7,8);
        System.out.println(result); 
    }
}